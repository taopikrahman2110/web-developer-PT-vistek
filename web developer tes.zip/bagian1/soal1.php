<?php

// deretan angka 1 sd 10
$deret = range(1, 10); 
$kelipatan2 = [];
$kelipatan3 = [];
$kelipatan4 = [];
$kelipatan5 = [];

// kelipatan sesuai 
foreach ($deret as $angka) {
  if ($angka % 2 == 0) {
    // tambah elemen ke akhir array
    array_push($kelipatan2, $angka);
  }
  if ($angka % 3 == 0) {
    array_push($kelipatan3, $angka);
  }
  if ($angka % 4 == 0) {
    array_push($kelipatan4, $angka);
  }
  if ($angka % 5 == 0) {
    array_push($kelipatan5, $angka);
  }
}

// jika kelipatan nya dua maka akan berwarna kuning 
echo "kelipatan 2 : ";
foreach ($deret as $angka) {
  if (in_array($angka, $kelipatan2)) {
    echo "<span style='color:yellow;'>$angka</span> ";
  } else {
    echo "$angka ";
  }
}
// jika kelipatan nya tiga maka akan berwarna merah 
echo "<br>kelipatan 3 : ";
foreach ($deret as $angka) {
  if (in_array($angka, $kelipatan3)) {
    echo "<span style='color:red;'>$angka</span> ";
  } else {
    echo "$angka ";
  }
}
// jika kelipatan nya empat maka akan berwarna kuning 
echo "<br>kelipatan 4 : ";
foreach ($deret as $angka) {
  if (in_array($angka, $kelipatan4)) {
    echo "<span style='color:yellow;'>$angka</span> ";
  } else {
    echo "$angka ";
  }
}
/// jika kelipatan nya lima maka akan berwarna merah 
echo "<br>kelipatan 5 : ";
foreach ($deret as $angka) {
  if (in_array($angka, $kelipatan5)) {
    echo "<span style='color:red;'>$angka</span> ";
  } else {
    echo "$angka ";
  }
}
?>

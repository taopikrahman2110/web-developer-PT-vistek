<!doctype html>
<html lang="en" data-bs-theme="auto">
<head>
    <script src="<?php echo e(asset('assets/js/color-modes.js')); ?>"></script>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.111.3">
    <title>Album example · Bootstrap v5.3</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/5.3/examples/album/">
    <link href="<?php echo e(asset('/assets/dist/css/bootstrap.min.css')); ?>" rel="stylesheet">


</head>
<body>


<main>

    <section class="text-center container">
        <div class="row py-lg-5">
            <div class="col-lg-6 col-md-8 mx-auto">
                <?php $__currentLoopData = $tim; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <img class="d-block mx-auto mb-4" src="<?php echo e(asset('images/tims/'.$t->logo)); ?>" alt="" width="300"
                         height="300">
                    <h1 class="fw-light"><?php echo e($t->name); ?></h1>
                    <p class="lead text-body-secondary">"<?php echo e($t -> deskripsi); ?>"</p>
                    <p class="lead text-body-secondary"><?php echo e($t -> archievment); ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <h1 class="text-center">Pemain</h1>
    <div class="album py-5 bg-body-tertiary">
        <div class="container">

            <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
                <?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col">

                        <div class="card shadow-sm">
                            <img src="<?php echo e(asset('images/pemains/'.$pl->foto)); ?>"alt="">
                            <div class="card-body text-center">
                                <h5><?php echo e($pl->name); ?></h5>
                                <p><?php echo e($pl->ign); ?></p>
                                <b> <td><?php echo e($pl->tim->name); ?></td></b>



                            </div>
                            <div class="btn-group">
                                <button type="button" class="btn btn-sm btn-outline-secondary"><a href="<?php echo e($pl->instagram); ?>">Instagram</a></button>
                                <button type="button" class="btn btn-sm btn-outline-secondary"><a href="<?php echo e($pl->facebok); ?>">Facebook</a></button>
                            </div>
                        </div>


                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>
    </div>

</main>


<script src="<?php echo e(asset('assets/dist/js/bootstrap.bundle.min.js')); ?>"></script>


</body>
</html>
<?php /**PATH D:\bagian2-tes\resources\views/tim/index.blade.php ENDPATH**/ ?>
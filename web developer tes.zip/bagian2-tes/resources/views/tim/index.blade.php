<!doctype html>
<html lang="en" data-bs-theme="auto">
<head>
    <script src="{{asset('assets/js/color-modes.js')}}"></script>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.111.3">
    <title>Album example · Bootstrap v5.3</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/5.3/examples/album/">
    <link href="{{asset('/assets/dist/css/bootstrap.min.css')}}" rel="stylesheet">


</head>
<body>


<main>

    <section class="text-center container">
        <div class="row py-lg-5">
            <div class="col-lg-6 col-md-8 mx-auto">
                @foreach ($tim as $t)
                    <img class="d-block mx-auto mb-4" src="{{ asset('images/tims/'.$t->logo) }}" alt="" width="300"
                         height="300">
                    <h1 class="fw-light">{{$t->name}}</h1>
                    <p class="lead text-body-secondary">"{{$t -> deskripsi}}"</p>
                    <p class="lead text-body-secondary">{{$t -> archievment}}</p>
                @endforeach
            </div>
        </div>
    </section>
    <h1 class="text-center">Pemain</h1>
    <div class="album py-5 bg-body-tertiary">
        <div class="container">

            <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
                @foreach($players as $pl)
                    <div class="col">

                        <div class="card shadow-sm">
                            <img src="{{ asset('images/pemains/'.$pl->foto) }}"alt="">
                            <div class="card-body text-center">
                                <h5>{{$pl->name}}</h5>
                                <p>{{$pl->ign}}</p>
                                <b> <td>{{ $pl->tim->name }}</td></b>



                            </div>
                            <div class="btn-group">
                                <button type="button" class="btn btn-sm btn-outline-secondary"><a href="{{$pl->instagram}}">Instagram</a></button>
                                <button type="button" class="btn btn-sm btn-outline-secondary"><a href="{{$pl->facebok}}">Facebook</a></button>
                            </div>
                        </div>


                    </div>
                @endforeach
            </div>

        </div>
    </div>

</main>


<script src="{{asset('assets/dist/js/bootstrap.bundle.min.js')}}"></script>


</body>
</html>

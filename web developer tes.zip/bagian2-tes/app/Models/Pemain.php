<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Pemain extends Model
{
    use HasFactory;

    protected $fillable = [
        'tim_id',
        'name',
        'foto',
        'ign',
        'instagram',
        'facebok',
    ];

    public function tim ()
    {
        return $this->belongsTo(Tim::class);
    }
}

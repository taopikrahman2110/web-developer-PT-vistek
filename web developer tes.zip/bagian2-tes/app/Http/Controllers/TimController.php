<?php

namespace App\Http\Controllers;

use App\Models\Pemain;
use App\Models\Tim;

class TimController extends Controller
{
    public function index()
    {
        $tim = Tim::with('pemains')->get();
        $players = Pemain::with('tim')->get();
        return view('tim.index', compact('tim','players'));
    }
}

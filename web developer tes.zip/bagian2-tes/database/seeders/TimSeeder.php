<?php

namespace Database\Seeders;

use App\Models\Tim;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Storage;

class TimSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
       $dataTims = [
           [
               'name' => 'veni vidi vici',
               'logo' => 'images.jpg',
               'deskripsi' => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis eros. Nullam malesuada erat ut turpis. Suspendisse urna nibh, viverra non, semper suscipit, posuere a, pede.',
               'archievment' => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.',
           ],
       ];

       foreach ($dataTims as $dataTim){

           $tim = new Tim([
               'name' => $dataTim['name'],
               'logo' => $dataTim['logo'],
               'deskripsi' => $dataTim['deskripsi'],
               'archievment' => $dataTim['archievment'],
           ]);

           $tim->save();
       }
    }
}

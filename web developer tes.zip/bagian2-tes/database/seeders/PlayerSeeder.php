<?php

namespace Database\Seeders;

use App\Models\Pemain;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Storage;

class PlayerSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $dataPlayers = [
            [
                'tim_id' => '1',
                'name' => 'Tony Krogh',
                'foto' => 'pemain1.jpg',
                'ign' => 'VVVTony',
                'instagram' => 'https://instagram.com/tony ',
                'facebok' => 'https://facebook.com/tony',
            ],[
                'tim_id' => '1',
                'name' => 'Stig Olsen',
                'foto' => 'pemain1.jpg',
                'ign' => 'VVVStig',
                'instagram' => 'https://instagram.com/stig ',
                'facebok' => 'https://facebook.com/stig',
            ],[
                'tim_id' => '1',
                'name' => 'Jannik Abildgaard',
                'foto' => 'pemain1.jpg',
                'ign' => 'VVVJannik',
                'instagram' => 'https://instagram.com/jannik',
                'facebok' => 'https://facebook.com/jannik',
            ],[
                'tim_id' => '1',
                'name' => 'Steffen Wulff',
                'foto' => 'pemain1.jpg',
                'ign' => 'VVVSteffen',
                'instagram' => 'https://instagram.com/steffen',
                'facebok' => 'https://facebook.com/steffen',
            ],[
                'tim_id' => '1',
                'name' => 'Storm Mork',
                'foto' => 'pemain1.jpg',
                'ign' => 'VVVStorm',
                'instagram' => 'https://instagram.com/storm',
                'facebok' => 'https://facebook.com/storm',
            ],
        ];

        foreach ($dataPlayers as $dataPlayer){


            $player = new Pemain([
                'tim_id' => $dataPlayer['tim_id'],
                'name' => $dataPlayer['name'],
                'foto' => $dataPlayer['foto'],
                'ign' => $dataPlayer['ign'],
                'instagram' => $dataPlayer['instagram'],
                'facebok' => $dataPlayer['facebok'],
            ]);

            $player->save();
        }
    }
}

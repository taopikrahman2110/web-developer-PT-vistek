<?php 
$data = [
    //  "1022334 - Hilda","1212343 - Nana","1098668 - Roger","1152671 - Kimmy","1166378 - Natan","1244567 - Carmilla"
    '1022334 - Hilda','1212343 - Nana','1098668 - Roger','1152671 - Kimmy','1269378 - Angela','1166378 - Natan','1244567 - Carmilla'  
];

$group1 = [];
$group2 = [];
$group3 = [];

foreach ($data as $item) {
    $nomor_induk = substr($item, 0, 2);
    if ($nomor_induk == '10') {
        array_push($group1, $item);
    } elseif ($nomor_induk == '11') {
        array_push($group2, $item);
    } elseif ($nomor_induk == '12') {
        array_push($group3, $item);
    }
}


echo '<table border="1" width="100%">';
echo '<tr><th>Group 1</th><th>Group 2</th><th>Group 3</th></tr>';

$max_count = max(count($group1), count($group2), count($group3));
for ($i = 0; $i < $max_count; $i++) {
    echo '<tr>';
    
    // data grup 1
    if (isset($group1[$i])) {
        echo '<td>'.$group1[$i].'</td>';
    } else {
        echo '<td></td>';
    }
    
    // data grup 2
    if (isset($group2[$i])) {
        echo '<td>'.$group2[$i].'</td>';
    } else {
        echo '<td></td>';
    }
    
    // data grup 3
    if (isset($group3[$i])) {
        echo '<td>'.$group3[$i].'</td>';
    } else {
        echo '<td></td>';
    }
    
    echo '</tr>';
}

echo '</table>';

?>